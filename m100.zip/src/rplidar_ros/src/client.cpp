#include "ros/ros.h"
#include <string.h> 
#include "sensor_msgs/LaserScan.h"

#include <pcl/point_types.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/search/search.h>
#include <pcl/search/kdtree.h>
#include <pcl/segmentation/extract_clusters.h>

#include <rplidar_ros/obstacleMsg.h>
#include <std_msgs/Float32MultiArray.h>

// #include <fstream>

// using namespace std;


#ifndef RAD2DEG
#define RAD2DEG(x) ((x)*180./M_PI)
#endif

#ifndef DEG2RAD
#define DEG2RAD(x) ((x)*M_PI/180.)
#endif


pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_msg (new pcl::PointCloud<pcl::PointXYZ>);
rplidar_ros::obstacleMsg obstacle;
//pcl::visualization::PCLVisualizer viewer;

int _isnan(double x) { return x != x; }
int _isinf(double x) { return !_isnan(x) && _isnan(x - x); }

float cartesian_to_polar(float x, float y)
{
    float degree;
    degree = RAD2DEG(atan(y/x));
    if (y<0 && x<0)
        degree -= 180;
    if (x<0 && y>0)
        degree += 180;
    
    if (y==0 && x>0)
        degree = 90;
    else if (y==0 && x<0)
        degree = -90;
    else if (y>0 && x==0)
        degree = 0;
    else if (y<0 && x==0)
        degree = 180;
    return degree;
}

void euclidean_clustering(ros::Publisher *pub, const sensor_msgs::LaserScan::ConstPtr& scan)
{
    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>);
    tree->setInputCloud (cloud_msg);
    //被分割出来的点云团（标号队列）
    std::vector<pcl::PointIndices> cluster_indices;
    //欧式分割器
    pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
    ec.setClusterTolerance (0.3); // 1=1m
    ec.setMinClusterSize (5);
    ec.setMaxClusterSize (25000);
    //搜索策略树
    ec.setSearchMethod (tree);
    ec.setInputCloud (cloud_msg);
    ec.extract (cluster_indices);

    //std::cout << "------------------"  << std::endl;
    //std::cout << "-----"  << cluster_indices.size () << std::endl;
    int j=0;
    obstacle.center.resize(0);
    for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
    { //迭代容器中的点云的索引，并且分开保存索引的点云
        //pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_cluster (new pcl::PointCloud<pcl::PointXYZ>);
        float pos_second_degree=300, pos_first_degree=-300, neg_second_degree=300, neg_first_degree=-300; 
        float min_radius=1000, first_degree=0, second_degree=0;
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_cluster (new pcl::PointCloud<pcl::PointXYZ>);
        for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit){
            //设置保存点云的属性问题
            cloud_cluster->points.push_back (cloud_msg->points[*pit]); //*
            cloud_cluster->width = cloud_cluster->points.size ();
            cloud_cluster->height = 1;
            cloud_cluster->is_dense = true;
            //std::cout << "+++++"  << *pit << std::endl;
            int i=*pit;
            //ROS_INFO("%f %f %f",cloud_msg->points[i].x,cloud_msg->points[i].y,cloud_msg->points[i].z);
            //ROS_INFO("%f %f %f", RAD2DEG(scan->angle_min + scan->angle_increment * i),scan->ranges[i]);
            float x,y,degree;
            degree = RAD2DEG(scan->angle_min + scan->angle_increment * i);
            x = scan->ranges[i]*cos(DEG2RAD(degree));
            y = scan->ranges[i]*sin(DEG2RAD(degree));
            //ROS_INFO("%f %f %f %f",degree, scan->ranges[i],cloud_msg->points[i].x,cloud_msg->points[i].y);
            
            if (degree>=0)
            {
                if (pos_second_degree > degree)
                    pos_second_degree = degree;
                if (pos_first_degree < degree)
                    pos_first_degree = degree;
                
            }
            else
            {
                if (neg_second_degree > degree)
                    neg_second_degree = degree;
                if (neg_first_degree < degree)
                    neg_first_degree = degree;
                    
            }
            
            if (min_radius > scan->ranges[i])
                min_radius = scan->ranges[i];
        }

        //ROS_INFO("******%f %f %f %f",pos_second_degree, pos_first_degree, neg_second_degree, neg_first_degree);

        float temp_x=0,temp_y=0,temp_z=0;
        for(int i=0;i<cloud_cluster->points.size();i++)
        {   
            //ROS_INFO("%f %f %f", cloud_cluster->points[i].x,cloud_cluster->points[i].y,cloud_cluster->points[i].z);
            temp_x += cloud_cluster->points[i].x;
            temp_y += cloud_cluster->points[i].y;
        }
        geometry_msgs::Point32 cluster_center;
        cluster_center.x = temp_x/cloud_cluster->points.size();
        cluster_center.y = temp_y/cloud_cluster->points.size();

        //ROS_INFO("******%d %f %f ",cloud_cluster->points.size(), cluster_center.x, cluster_center.y);
        float center_degree = cartesian_to_polar(cluster_center.x, cluster_center.y);
        if (abs(pos_first_degree+neg_second_degree) < 5 && abs(pos_first_degree)>150 && abs(neg_second_degree)>150)
        {
            second_degree = pos_second_degree;
            first_degree = neg_first_degree;
            //std::cout << "if 1" << std::endl;
        }
        else
        {
            if (neg_second_degree > 200)   //没有负数
            {
                second_degree = pos_second_degree;
                first_degree = pos_first_degree;
                //std::cout << "if 2" << std::endl;
            }
            else if (pos_first_degree < -200)     //没有正数
            {
                second_degree = neg_second_degree;
                first_degree = neg_first_degree;
                //std::cout << "if 3" << std::endl;
            }
            else    //有正有负
            {
                second_degree = neg_second_degree;
                first_degree = pos_first_degree;
                //std::cout << "if 4" << std::endl;
            }
        }
        //ROS_INFO("******%f %f",first_degree, second_degree);

        //ROS_INFO("%f %f", center_degree, min_radius);

        if(_isnan(center_degree) != 1)
        {
            geometry_msgs::Point32 temp_obstacle;
            temp_obstacle.x = min_radius;
            temp_obstacle.y = first_degree;
            temp_obstacle.z = second_degree;
            obstacle.center.push_back(temp_obstacle);
        }
        else
        {
            continue;
        }

        //ROS_INFO("%d %d", cloud_msg->points.size(), cloud_cluster->points.size());
        //std::cout << std::endl << std::endl;
        // viewer.removePointCloud("cloud"); 
        // viewer.addPointCloud(cloud_msg, "cloud");
        
        //viewer.removePointCloud(std::to_string(j)+"3"); 
        //pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> rgb_points (cloud_cluster, 0, 255, 0);
        //viewer.addPointCloud(cloud_cluster, rgb_points, std::to_string(j)+"3");
        //viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,10,std::to_string(j)+"3");
        //viewer.spinOnce ();
        j++;
    }
    ROS_INFO("%d %d", cluster_indices.size(), obstacle.center.size());

    // for(int i=0;i<obstacle.center.size();i++)
    // {
    //     ROS_INFO("x=%f,y=%f,z=%f",obstacle.center[i].x,obstacle.center[i].y,obstacle.center[i].z);
    // }
    
    pub->publish(obstacle);
}

std::string getDirectory()
{
    char abs_path[1024];
    int cnt = readlink("/proc/self/exe", abs_path, 1024);//可执行程序绝对路径
    if(cnt < 0|| cnt >= 1024)
    {
        return NULL;
    }

    //清除部分路径，回退至工作空间下
    int count=0;
    for(int i = cnt; i >= 0; --i)
    {
        if(abs_path[i]=='/')
        {
            abs_path[i + 1]='\0';
            count++;

            if(count == 4)
            {
                break;
            }
        }
    }

    std::string path(abs_path);

    path = path + "src/";

    return path;
}

void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan, ros::Publisher *pub)
{
    // ofstream str;
    // string file_name(getDirectory() + "scan.txt");
    // str.open(file_name.c_str(),ios::app);

     int count = scan->ranges.size();
    // ROS_INFO("count=%d",count);
    // str<<count<<endl;

    // for(int i = 0; i < count; i++) {
    //     float degree = RAD2DEG(scan->angle_min + scan->angle_increment * i);
    //     ROS_INFO(": [%f, %f]", degree, scan->ranges[i]);
        
    //     str.precision(8);
    //     str<<degree<<","<<scan->ranges[i]<<endl;
    // }

    // str.close();

    //int count = scan->scan_time / scan->time_increment;
    //ROS_INFO("I heard a laser scan %s[%d]:", scan->header.frame_id.c_str(), count);
    //ROS_INFO("angle_range, %f, %f", RAD2DEG(scan->angle_min), RAD2DEG(scan->angle_max));

    cloud_msg->height = 1;
    cloud_msg->width  = count;
    cloud_msg->points.resize(cloud_msg->width * cloud_msg->height);
    for(int i = 0; i < count; i++) {
        float degree = RAD2DEG(scan->angle_min + scan->angle_increment * i);  
        if(scan->ranges[i] && (_isinf(scan->ranges[i])==0)){
            cloud_msg->points[i].x = scan->ranges[i]*cos(DEG2RAD(degree));
            cloud_msg->points[i].y = scan->ranges[i]*sin(DEG2RAD(degree));
            cloud_msg->points[i].z = 0;
        }
        else
        {
            cloud_msg->points[i].x = 0;
            cloud_msg->points[i].y = 0;
            cloud_msg->points[i].z = 0;
        }
    }
    //ROS_INFO("\n");
    //ROS_INFO("cloud size is %d", cloud_msg->points.size());

    // viewer.removePointCloud("cloud"); 
    // viewer.addPointCloud(cloud_msg, "cloud");
    // viewer.spinOnce ();

    euclidean_clustering(pub, scan);

}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "rplidar_node_client");
    ros::NodeHandle n;
    ros::NodeHandle nh_private("~");

    std::string uav_name;
    nh_private.param<std::string>("uav_name",uav_name,"m100");

    ros::Publisher obstacle_pub = n.advertise<rplidar_ros::obstacleMsg>(std::string(uav_name + "/obstacle").c_str(), 1000);
    ros::Subscriber sub = n.subscribe<sensor_msgs::LaserScan>(std::string(uav_name + "/scan").c_str(), 1000, boost::bind(&scanCallback, _1, &obstacle_pub));
    
    ros::spin();

    ros::shutdown();
    return 0;
}
