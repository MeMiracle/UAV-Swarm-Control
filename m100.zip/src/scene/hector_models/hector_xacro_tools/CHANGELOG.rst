^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_xacro_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.2 (2016-06-24)
------------------
* Add joint macros (contains transmission macro for the moment)
* Contributors: Stefan Kohlbrecher

0.4.1 (2015-11-08)
------------------
* hector_xacro_tools: fixed invalid brackets in inertial_sphere* xacro macros
* Cleaned up root element xmlns arguments according to http://gazebosim.org/tutorials?tut=ros_urdf#HeaderofaURDFFile
* Added missing xacro namespace prefix to XML tags
* Contributors: Johannes Meyer

0.4.0 (2015-11-07)
------------------
* Remove origin tag as already set via insert block
* Add additional macros
* Contributors: kohlbrecher

0.3.2 (2014-09-01)
------------------

0.3.1 (2014-03-30)
------------------

0.3.0 (2013-09-02)
------------------
* catkinized stack hector_models
