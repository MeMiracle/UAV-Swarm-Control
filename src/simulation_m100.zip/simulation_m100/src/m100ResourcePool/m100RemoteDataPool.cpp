#include <ros/ros.h>
#include <stdlib.h>
#include <vector>
#include <simulation_m100/PubSubUavMsg.h>
#include <m100Location/uwblpsmessage.pb.h>
#include <m100Location/uwblpsmessage.pb.cc>
#include <simulation_m100/Position.h>

using namespace std;

int uav_id = -1;//本机id,默认为-1，再通过初始化工作获取实际id
string uav_name("");

void subOtherUavPosCallback(simulation_m100::PubSubUavMsg other_uav_pos_msg);//实时更新其他无人系统位置
void subOtherUavFdDataCallback(simulation_m100::PubSubUavMsg other_uav_fd_data_msg);//实时更新其他无人系统状态数据
void subOtherUavFdWPCallback(simulation_m100::PubSubUavMsg other_uav_fd_wp_msg);
void subOtherUavMBCallback(simulation_m100::PubSubUavMsg other_uav_mb_msg);
void subPosCallback(simulation_m100::Position pos_msg);//位置更新

struct Point3D {
	/*
	* 记录位置点
	*/
	float x;
	float y;
	float z;
	Point3D() {
		x = 0;
		y = 0;
		z = 0;
	}
	Point3D(float tx, float ty) {
		x = tx;
		y = ty;
		z = 0;
	}
	Point3D(float tx, float ty, float tz) {
		x = tx;
		y = ty;
		z = tz;
	}
	bool operator==(const Point3D& p)
	{
		if (this->x == p.x)
			return this->y == p.y;
		else
			return false;
	}

	bool operator<(const Point3D& p)
	{
		if (this->x < p.x)
			return this->y<p.y;
		else return (this->x + this->y) < (p.x + p.y);
	}

	void operator=(const Point3D& p)
	{
		this->x = p.x;
		this->y = p.y;
		this->z = p.z;
	}

	double operator-(const Point3D &other) const {
		auto x_ = abs(this->x - other.x);
		auto y_ = abs(this->y - other.y);
		auto z_ = abs(this->z - other.z);
		return sqrt(pow(x_, 2) + pow(y_, 2) + pow(z_, 2));
	}

};

int main(int argc, char *argv[])
{
    /* code for main function */
    ros::init(argc, argv, "m100RemoteDataPool");
    ros::NodeHandle nh;

	ROS_INFO("m100RemoteDataPool_node started.");

	ros::param::get("~uav_id",uav_id);
    if(uav_id == -1)
    {
        return -1;
    }

    ros::param::get("~uav_name",uav_name);

	int axisID = 1;
    string posTopic("/global_position");
    ros::param::get("~axis_id", axisID);
	if (axisID == 2)
	{
		posTopic = string("/local_position");
	}

    ros::Subscriber other_uav_pos_sub = nh.subscribe(string(uav_name + "/other_uav_pos").c_str(), 10, subOtherUavPosCallback);//其他无人系统uwb定位
    ros::Subscriber other_uav_feedback_data_sub = nh.subscribe(string(uav_name + "/other_uav_feedback_data").c_str(),10,subOtherUavFdDataCallback);//其他无人系统反馈数据
    ros::Subscriber other_uav_feedback_waypoint_sub = nh.subscribe(string(uav_name + "/other_uav_fd_waypoint").c_str(), 10, subOtherUavFdWPCallback);
	ros::Subscriber other_uav_mapbuffer_sub = nh.subscribe(string(uav_name + "/other_uav_mapbuffer"), 10, subOtherUavMBCallback);
	ros::Subscriber global_pos_sub = nh.subscribe(string(uav_name + posTopic).c_str(), 10, subPosCallback);

	ros::spin();

	ros::shutdown();
	
    return 0;
}

// vector<Point3D> swarmPositionBuf;
// vector<int> uavIndexBuf;
std::map<int, Point3D> swarmPosition;

void updateSwarmPosition(int src_uav_id,Point3D point){
/*
	// int i=0;
	// for(i;i<uavIndexBuf.size();i++)
	// {
	// 	if(src_uav_id == uavIndexBuf[i])//缓存中有该无人系统的数据，则更新
	// 	{
	// 		swarmPositionBuf[i] = point;

	// 		//swarmPositionBuf.erase(i);
	// 		//swarmPositionBuf.push_back(point);

	// 		break;
	// 	}
	// }

	// if(i == uavIndexBuf.size())//缓存中没有该无人系统的数据，则存入
	// {
	// 	uavIndexBuf.push_back(src_uav_id);
	// 	swarmPositionBuf.push_back(point);
	// }
*/

    if(swarmPosition.find(src_uav_id) != swarmPosition.end())//缓存中有该无人系统的数据，则更新
    {
        swarmPosition[src_uav_id] = point;
    }
    else
    {
        swarmPosition.insert(pair<int,Point3D>(src_uav_id,point));
    }  

	// static ros::Time timeToShow = ros::Time::now();
    // if(ros::Time::now() - timeToShow >= ros::Duration(1))
    // {
		std::map<int,Point3D>::iterator iter;
		iter = swarmPosition.begin();

		while(iter != swarmPosition.end()){
			ROS_INFO("uav%d:%lf,%lf,%lf",iter->first,iter->second.x,iter->second.y,iter->second.z);
			iter ++;
		} 
		printf("\n"); 

	// 	timeToShow = ros::Time::now();
    // }  
}

void subOtherUavPosCallback(simulation_m100::PubSubUavMsg other_uav_pos_msg)//实时更新其他无人系统位置
{
	uwblpsMessage::uwblpsMessage other_uav_pos;
	other_uav_pos.ParseFromString(other_uav_pos_msg.playload);

	Point3D point(other_uav_pos.linear_x(),other_uav_pos.linear_y(),other_uav_pos.linear_z());

	int src_uav_id = other_uav_pos_msg.src_uav_id;

	updateSwarmPosition(src_uav_id,point);
}

void subPosCallback(simulation_m100::Position pos_msg)//位置更新
{
    Point3D point(pos_msg.x,pos_msg.y,pos_msg.z);

	int src_uav_id = uav_id;

	updateSwarmPosition(src_uav_id,point);
}

void subOtherUavFdDataCallback(simulation_m100::PubSubUavMsg other_uav_fd_data_msg)//实时更新其他无人系统状态数据
{

}

void subOtherUavFdWPCallback(simulation_m100::PubSubUavMsg other_uav_fd_wp_msg)
{

}

void subOtherUavMBCallback(simulation_m100::PubSubUavMsg other_uav_mb_msg)
{
	
}